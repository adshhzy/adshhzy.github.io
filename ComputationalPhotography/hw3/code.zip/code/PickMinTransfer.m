function [choice] = PickMinTransfer(iminBig,imageIntensity,iminTrans,iminPreS,iminSa1,iminSa2,alpha,nSample,nMethod,overlapsize,X,Y,isPre)

[sy,sx,~] = size(iminBig);
[ly,lx,~] = size(iminSa1);


hOsize = overlapsize;

xed = lx-hOsize+1;
xst = hOsize;

yed = ly-hOsize+1;
yst = hOsize;

% x =  zeros(nSample,1);
% y =  zeros(nSample,1);
errleft =  zeros(nSample,1);
errup =  zeros(nSample,1);
errtransfer =  zeros(nSample,1);
errPres =  zeros(nSample,1);
nseeds = randperm((sx-lx-1)*(sy-ly-1),nSample);

x = X(nseeds);
y = Y(nseeds);

xi = x + overlapsize/2+1;
yi = y + overlapsize/2+1;
lyi = ly - overlapsize;
lxi = lx - overlapsize;

for i = 1:nSample
    
%     [patch,x(i),y(i)] = RanCutImage(iminBig,lx,ly);


    patch = iminBig(y(i):y(i)+ly-1,x(i):x(i)+lx-1,:);

    

    
    if(nMethod==3 || nMethod ==1)errleft(i) = leftErr(iminSa1,patch,yst,yed,xst,xed);end
    if(nMethod==3 || nMethod ==2)errup(i) = upErr(iminSa2,patch,yst,yed,xst,xed);end
    
    errtransfer(i) =  transErr(imageIntensity(yi(i):yi(i)+lyi-1,xi(i):xi(i)+lxi-1,:),iminTrans);
    if(nMethod==3 )errtransfer(i) = errtransfer(i)*2;end
    if(isPre)
        errPres(i) =  transErr(iminBig(yi(i):yi(i)+lyi-1,xi(i):xi(i)+lxi-1,:),iminPreS);
%         if(nMethod==3 )errPres(i) = errPres(i)*2;end
    end
    
    
end

FinErr = alpha*(errleft + errup + errPres)+(1-alpha)*errtransfer;

[C,Ind] = min(FinErr);


choice = iminBig(y(Ind):y(Ind)+ly-1,x(Ind):x(Ind)+lx-1,:);







end


function [err] = leftErr(imin1,imin2,yst,yed,xst,xed)
% a1 = imin1(yst:yed,xed:end,:);
% a2 = imin2(yst:yed,1:xst,:);

aa = imin1(yst:yed,xed:end,:) -  imin2(yst:yed,1:xst,:);

aa = aa.*aa;

err = sum(aa(:));


end

function [err] = upErr(imin1,imin2,yst,yed,xst,xed)


aa = imin1(yed:end,xst:xed,:) -  imin2(1:yst,xst:xed,:);

aa = aa.*aa;

err = sum(aa(:));


end

function [err] = transErr(imP,imT)



aa = imP - imT;
aa = aa.*aa;
err = sum(aa(:));

end
