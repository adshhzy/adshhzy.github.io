function [choice] = PickMinCut(iminSa1,iminSa2,nMethod,overlapsize)

[ly,lx,~] = size(iminSa1);


hOsize = overlapsize;

xed = lx-hOsize+1;
xst = hOsize;

yed = ly-hOsize+1;
yst = hOsize;




    
%     [patch,x(i),y(i)] = RanCutImage(iminBig,lx,ly);



    
if( nMethod == 1)
    choice = leftErr(iminSa1,iminSa2,yst,yed,xst,xed);
else
    choice = upErr(iminSa1,iminSa2,yst,yed,xst,xed);
end
    
    







end


function [cutRegion] = leftErr(imin1,imin2,yst,yed,xst,xed)
% a1 = imin1(yst:yed,xed:end,:);
% a2 = imin2(yst:yed,1:xst,:);

% aa = imin1(yst:yed,xed:end,:) -  imin2(yst:yed,2:xst+1,:);
aa = imin1(:,xed:end,:) -  imin2(:,2:xst+1,:);

aa = aa.*aa;

aa = sum(aa,3);

ee = aa;

[y,x] = size(aa);
index = zeros(y,x);
for i = 2: y
   for j = 1: x
      if(j==1)
          [C,index(i,j)] = min(ee(i-1,1:2));
          ee(i,j) = ee(i,j)+C;
          index(i,j) = index(i,j)+1;
          continue;
      end
      if(j==x)
          [C,index(i,j)] = min(ee(i-1,x-1:x));
          ee(i,j) = ee(i,j)+C;
          continue;
      end
      [C,index(i,j)] = min(ee(i-1,j-1:j+1));
      ee(i,j) = ee(i,j)+C;
      
   end
end

[C,I] = min(ee(y,:));
index = index-2;
cuttt = zeros(y,1);
cuttt(y) = I;
for i = y:-1:2
    cuttt(i-1) = cuttt(i) + index(i, cuttt(i));    
end


cutRegion = zeros(y,x,3);

for i = 1:y  
    cutline = cuttt(i);
%     cutRegion(i,1:cutline,:) = imin1(yst+i-1,xed:xed+cutline-1,:); 
%     cutRegion(i,cutline+1:end,:) = imin2(yst+i-1,cutline+1:xst,:);
    cutRegion(i,1:cutline,:) = imin1(i,xed:xed+cutline-1,:); 
    cutRegion(i,cutline+1:end,:) = imin2(i,cutline+1:xst,:);
end





end

function [cutRegion] = upErr(imin1,imin2,yst,yed,xst,xed)


% aa = imin1(yst:yed,xed:end,:) -  imin2(yst:yed,2:xst+1,:);
aa = imin1(yed:end,:,:) -  imin2(2:yst+1,:,:);

aa = aa.*aa;

aa = sum(aa,3);

ee = aa;

[y,x] = size(aa);
index = zeros(y,x);


for j = 2 : x
   for i = 1 : y
      if(i==1)
          [C,index(i,j)] = min(ee(1:2,j-1));
          ee(i,j) = ee(i,j)+C;
          index(i,j) = index(i,j)+1;
          continue;
      end
      if(i==y)
          [C,index(i,j)] = min(ee(y-1:y,j-1));
          ee(i,j) = ee(i,j)+C;
          continue;
      end
      [C,index(i,j)] = min(ee(i-1:i+1,j-1));
      ee(i,j) = ee(i,j)+C;
      
   end
end

[C,I] = min(ee(:,x));
index = index-2;
cuttt = zeros(x,1);
cuttt(x) = I;
for i = x:-1:2
    cuttt(i-1) = cuttt(i) + index(cuttt(i),i);    
end


cutRegion = zeros(y,x,3);

for i = 1:x  
    cutline = cuttt(i);
%     cutRegion(i,1:cutline,:) = imin1(yst+i-1,xed:xed+cutline-1,:); 
%     cutRegion(i,cutline+1:end,:) = imin2(yst+i-1,cutline+1:xst,:);
    cutRegion(1:cutline,i,:) = imin1(yed:yed+cutline-1,i,:); 
    cutRegion(cutline+1:end,i,:) = imin2(cutline+1:yst,i,:);
end




end