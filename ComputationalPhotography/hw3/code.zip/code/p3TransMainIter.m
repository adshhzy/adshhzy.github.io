% imin = im2double(imread('caustics.png'));
% imin = im2double(imread('FarmAerial.jpg'));
% imin = im2double(imread('cloud.jpeg'));
imin = im2double(imread('salty.jpeg'));

%  iminTrans =im2double(imread('faceTransfer.jpeg'));
% iminTrans =im2double(imread('who.png'));
iminTrans =im2double(imread('god.jpg'));


iminTrans = imresize(iminTrans, [720 720]);
% imIntensity = rgb2gray(imin);

iminPre=iminTrans;

iminTrans = rgb2gray(iminTrans);


blksizex = 80;
blksizey = 80;


overlapsize = 30;

NIter = 4;

alpha = 0.02;


for i = 0: NIter-1
    alpha = 0.8*(i)/(NIter-1)+0.1;
    
    iminPre = texTransferIter(imin,iminTrans,iminPre,alpha,i,blksizex,blksizey,overlapsize); 
    if(i == 0)
        blksizex = 60;
        blksizey = 60;
        overlapsize = 20;
    end
    if(i == 1)
        blksizex = 40;
        blksizey = 40;
        overlapsize = 16;
    end
    if(i == 2)
        blksizex = 30;
        blksizey = 30;
        overlapsize = 10;
    end
    

end