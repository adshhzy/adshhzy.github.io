% imin = im2double(imread('caustics.png'));
% imin = im2double(imread('FarmAerial.jpg'));
function [imout] = texTransferIter(imin,iminTrans,iminPre,alpha,isPre,blksizex,blksizey,overlapsize)


% imin = im2double(imread('cloud.jpeg'));


% iminTrans =rgb2gray(im2double(imread('faceTransfer.jpeg')));
% iminTrans = imresize(iminTrans, [500 500]);
imIntensity = rgb2gray(imin);


[outsize,~,~] = size(iminPre);
[sy,sx,~] = size(imin);

% blksizex = 50;
% blksizey = 50;

% overlapsize = 20;

hOsize = overlapsize/2;

ttlengx = blksizex + overlapsize;
ttlengy = blksizey + overlapsize;

xed = ttlengx-hOsize;
xst = hOsize+1;

yed = ttlengy-hOsize;
yst = hOsize+1;

% iminPre = zeros(500,500);


% nsample = (sx-ttlengx-1)*(sy-ttlengy-1);
nsample = 1000;

[X,Y] = meshgrid(1:sx-ttlengx,1:sy-ttlengy);

nran = sy*sx;

nbig = outsize/blksizex;

% alpha = 0.1;

patches  = cell(nbig,nbig);
patches{1,1} = RanCutImage(imin,ttlengx,ttlengy);
iminTransC  = cell(nbig,nbig);
iminPreC  = cell(nbig,nbig);
for i = 1:nbig
   for j = 1:nbig
       iminTransC{i,j} = iminTrans((i-1)*blksizey+1:(i)*blksizey,(j-1)*blksizex+1:(j)*blksizex);
       iminPreC{i,j} = iminPre((i-1)*blksizey+1:(i)*blksizey,(j-1)*blksizex+1:(j)*blksizex,:);            
   end
end
% isPre = 0;
for i = 1:nbig
   for j = 1:nbig
       if(i==1 && j==1)
           patches{1,1} = PickMinTransfer(imin,imIntensity,iminTransC{i,j},iminPreC{i,j},patches{1,1},patches{1,1},alpha,nsample,0,overlapsize,X,Y,isPre);
           continue;
       
       end
       if(i==1)
           patches{i,j} = PickMinTransfer(imin,imIntensity,iminTransC{i,j},iminPreC{i,j},patches{1,j-1},patches{1,j-1},alpha,nsample,1,overlapsize,X,Y,isPre);
           continue;
       end
       if(j==1)
           patches{i,j} = PickMinTransfer(imin,imIntensity,iminTransC{i,j},iminPreC{i,j},patches{i-1,j},patches{i-1,j},alpha,nsample,2,overlapsize,X,Y,isPre);
           continue;
       end
       
       patches{i,j} = PickMinTransfer(imin,imIntensity,iminTransC{i,j},iminPreC{i,j},patches{i-1,j},patches{i,j-1},alpha,nsample,2,overlapsize,X,Y,isPre);
              
   end
 
end


xxed = ttlengx-overlapsize+1;
xxst = overlapsize;

yyed = ttlengy-overlapsize+1;
yyst = overlapsize;

for i = 1:nbig
   for j = 2:nbig
       cutRegion = PickMinCut( patches{i,j-1}, patches{i,j},1,overlapsize);
%        patches{i,j-1}(yyst:yyed,end-overlapsize+1:end,:) = cutRegion(:,:,:);
%        patches{i,j}(yyst:yyed,1:overlapsize,:) = cutRegion(:,:,:);
       patches{i,j-1}(:,end-overlapsize+1:end,:) = cutRegion(:,:,:);
       patches{i,j}(:,1:overlapsize,:) = cutRegion(:,:,:);

   end
 
end
for i = 2:nbig
   for j = 1:nbig
       cutRegion = PickMinCut( patches{i-1,j}, patches{i,j},2,overlapsize);
%        patches{i,j-1}(yyst:yyed,end-overlapsize+1:end,:) = cutRegion(:,:,:);
%        patches{i,j}(yyst:yyed,1:overlapsize,:) = cutRegion(:,:,:);
       patches{i-1,j}(end-overlapsize+1:end,:,:) = cutRegion(:,:,:);
       patches{i,j}(1:overlapsize,:,:) = cutRegion(:,:,:);

   end
 
end





for i = 1:nbig
   for j = 1:nbig
       patches{i,j} = patches{i,j}(yst:yed,xst:xed,:);     
   end
end
rows = cell(nbig,1);
for i = 1:nbig
    rows{i} = cat(2,patches{i,:}); 
end


imout = cat(1,rows{:});
figure(isPre+1);imagesc(imout);




end