function [patch,x,y] = RanCutImage(imin,lx,ly)


[ssy,ssx,~] = size(imin);


x = randi(ssx-lx+1);
y = randi(ssy-ly+1);

patch = imin(y:y+ly-1,x:x+lx-1,:);



end